<?php
class Sterial_Questions_Widget extends \Elementor\Widget_Base {



    public function get_name() {
        return 'sterial-questions-widget';
    }

	public function get_title() {
        return __('Questions widget', 'sterial-helper');
    }

	public function get_icon() {
        return 'eicon-archive-posts';

    }
    protected function register_controls() {



        $this->start_controls_section(
			'questions_section',
			[
				'label' => esc_html__( 'Questions Section', 'sterial-helper' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

        $this->add_control(
			'image',
			[
				'label' => esc_html__( 'Choose Image', 'sterial-helper' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

        $this->add_control(
			'section_title',
			[
				'label' => esc_html__( 'Section Title', 'sterial-helper' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Type your Section title here', 'sterial-helper' ),
			]
		);

        $repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'question',
			[
				'label' => esc_html__( 'Question', 'sterial-helper' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Type your Question here', 'sterial-helper' ),
			]
		);

        $repeater->add_control(
			'answer',
			[
				'label' => esc_html__( 'Answer', 'sterial-helper' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Type your Answer here', 'sterial-helper' ),
			]
		);
        

        $this->add_control(
			'question_answer_boxes',
			[
				'label' => esc_html__( 'Question Answer Boxes', 'sterial-helper' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ question }}}',
			]
		);

        $this->end_controls_section();


	} 

	protected function render(){
		$settings = $this->get_settings_for_display();
        $image = $settings['image'];
        $image_url = $image['url'];
        $section_title = $settings['section_title'];
        $boxes = $settings['question_answer_boxes'];
        ?>
        <div class="section">
            <div class="container">
                <div class="row justify-content-between align-items-center">
                    <div class="col-lg-5 mb-4 mb-lg-0">
                        <img src="<?php echo esc_url($image_url); ?>" alt="Image" class="img-fluid">
                    </div>
                    <div class="col-lg-5 mt-4 mt-lg-0"  data-aos="fade-up" data-aos-delay="100">

                        <h2 class="heading mb-5"><?php echo esc_html( $section_title ); ?></h2>

                        <div class="custom-accordion" id="accordion_1">
                            <?php
                            if(is_array($boxes)){
                                foreach($boxes as $box){
                                    $question = $box['question'];
                                    $answer = $box['answer'];
                                    $counter = 1;
                                    ?>
                                    <div class="accordion-item">
                                        <h2 class="mb-0">
                                            <?php
                                            if($counter = 1){
                                                ?>
                                                <button class="btn btn-link" type="button"  data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne"><?php echo esc_html( $question ); ?></button>
                                                <?php
                                            }
                                            elseif($counter = 2){
                                                ?>
                                                <button class="btn btn-link" type="button"  data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo"><?php echo esc_html( $question ); ?></button>
                                                <?php
                                            }
                                            elseif($counter = 3){
                                                ?>
                                                <button class="btn btn-link" type="button"  data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="true" aria-controls="collapseThree"><?php echo esc_html( $question ); ?></button>
                                                <?php
                                            }
                                            elseif($counter = 4){
                                                ?>
                                                <button class="btn btn-link" type="button"  data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="true" aria-controls="collapseFour"><?php echo esc_html( $question ); ?></button>
                                                <?php
                                            }
                                            ?>
                                            
                                        </h2>
                                        <?php
                                        if($counter = 1){
                                            ?>
                                            <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-bs-parent="#accordion_1">
                                                <div class="accordion-body">
                                                    <?php echo esc_html( $answer ); ?>
                                                </div>
                                            </div>
                                            <?php
                                        }
                                        elseif($counter = 2){
                                            ?>
                                            <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-bs-parent="#accordion_1">
                                                <div class="accordion-body">
                                                    <?php echo esc_html( $answer ); ?>
                                                </div>
                                            </div>
                                            <?php

                                        }
                                        elseif($counter = 3){
                                            ?>
                                            <div id="collapseThree" class="collapse show" aria-labelledby="headingThree" data-bs-parent="#accordion_1">
                                                <div class="accordion-body">
                                                    <?php echo esc_html( $answer ); ?>
                                                </div>
                                            </div>
                                            <?php
                                        }
                                        elseif($counter = 4){
                                            ?>
                                            <div id="collapseFour" class="collapse show" aria-labelledby="headingFour" data-bs-parent="#accordion_1">
                                                <div class="accordion-body">
                                                    <?php echo esc_html( $answer ); ?>
                                                </div>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                        <?php
                                        $counter = $counter+1;
                                        ?>
                                        
                                    </div> <!-- .accordion-item -->
                                    <?php

                                }
                            }
                            ?>
                            

                            

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
		
	}

}