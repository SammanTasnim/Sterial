<?php 


class Sterial_Explore_Widget extends \Elementor\Widget_Base {

	public function get_name() {
        return 'sterial-explore-widget';
    }

	public function get_title() {
        return __('Explore widget', 'sterial-helper');
    }

	public function get_icon() {
        return 'eicon-archive-posts';
    }

	protected function register_controls() {
		
        
        $this->start_controls_section(
			'explore',
			[
				'label' => esc_html__( 'Explore Section', 'sterial-helper' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

        $this->add_control(
			'explore_title',
			[
				'label' => esc_html__( 'Title', 'sterial-helper' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Type your text here', 'sterial-helper' ),
			]
		);




        $this->add_control(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'sterial-helper' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		

        $this->add_control(
			'link',
			[
				'label' => esc_html__( 'Link', 'proshoot-helper' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Type your link here', 'sterial-helper' ),
			]
		);
 
        

        $this->add_control(
			'image1',
			[
				'label' => esc_html__( 'Choose Image', 'sterial-helper' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

        $this->add_control(
			'image2',
			[
				'label' => esc_html__( 'Choose Image', 'sterial-helper' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

        $this->end_controls_section();


        

    }

	protected function render() {
        $settings = $this->get_settings_for_display();
        $title = $settings['explore_title'];
        $content = $settings['content_section'];
        $link = $settings['link'];
        $image1 = $settings['image1'];
        $img1_url = $image1['url'];
        $image2 = $settings['image2'];
        $img2_url = $image2['url'];
        ?>
        <div class="section section-2">
            <div class="container">
                <div class="row align-items-center justify-content-between">
                    <div class="col-lg-6 order-lg-2 mb-5 mb-lg-0">
                        <div class="image-stack mb-5 mb-lg-0">
                            <div class="image-stack__item image-stack__item--bottom" data-aos="fade-up"  >
                                <img src="<?php echo esc_url($img1_url); ?>" alt="Image" class="img-fluid rellax ">
                            </div>
                            <div class="image-stack__item image-stack__item--top" data-aos="fade-up" data-aos-delay="100"  data-rellax-percentage="0.5">
                                <img src="<?php echo esc_url($img2_url); ?>" alt="Image" class="img-fluid">
                            </div>
                        </div>

                    </div>
                    <div class="col-lg-4 order-lg-1">

                        <div>
                            <h2 class="heading mb-3" data-aos="fade-up" data-aos-delay="100"><?php echo esc_html( $title ); ?></h2>

                            <p data-aos="fade-up" data-aos-delay="200"><?php echo esc_html( $content ); ?></p>

                            <p class="my-4" data-aos="fade-up" data-aos-delay="300"><a href="<?php echo esc_url($link); ?>" class="btn btn-primary">Read more</a></p>
                        </div>
                    </div>
                    
                </div>

            </div>		
        </div>
        <?php

    }
}



