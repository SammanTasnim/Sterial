<?php
class Sterial_Destination_Widget extends \Elementor\Widget_Base {



    public function get_name() {
        return 'sterial-destination-widget';
    }

	public function get_title() {
        return __('Destination widget', 'sterial-helper');
    }

	public function get_icon() {
        return 'eicon-archive-posts';

    }
    protected function register_controls() {

        $this->start_controls_section(
			'destination_sec',
			[
				'label' => esc_html__( 'Destination Section', 'sterial-helper' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		
		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'sterial-helper' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Type your title here', 'sterial-helper' ),
			]
		);
		$this->add_control(
			'content',
			[
				'label' => esc_html__( 'Content', 'sterial-helper' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Type your content here', 'sterial-helper' ),
			]
		);











		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'price',
			[
				'label' => esc_html__( 'Price', 'sterial-helper' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Type your price here', 'sterial-helper' ),
			]
		);

		$repeater->add_control(
			'location',
			[
				'label' => esc_html__( 'Location', 'sterial-helper' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Type your location here', 'sterial-helper' ),
			]
		);

		$repeater->add_control(
			'country',
			[
				'label' => esc_html__( 'Country', 'sterial-helper' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Type your country here', 'sterial-helper' ),
			]
	    );

		$repeater->add_control(
			'image',
			[
				'label' => esc_html__( 'Choose Image', 'sterial-helper' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);


		$this->add_control(
			'destination_boxes',
			[
				'label' => esc_html__( 'Destination Boxes', 'sterial-helper' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ location }}}',
			]
		);

        $this->end_controls_section();

	} 

	protected function render(){
		$settings = $this->get_settings_for_display();
		$destination_heading = $settings['title'];
		$destination_content = $settings['content'];
		$boxes = $settings['destination_boxes'];
		?>
			<div class="section section-3" data-aos="fade-up" data-aos-delay="100">
				<div class="container">
					<div class="row align-items-center justify-content-between  mb-5">
						<div class="col-lg-5" data-aos="fade-up">
							<h2 class="heading mb-3"><?php echo esc_html( $destination_heading ); ?></h2>
							<p><?php echo esc_html( $destination_content ); ?></p>
						</div>		
						<div class="col-lg-5 text-md-end" data-aos="fade-up" data-aos-delay="100">
							<div id="destination-controls">
								<span class="prev me-3" data-controls="prev">
									<span class="icon-chevron-left"></span>

								</span>
								<span class="next" data-controls="next">
									<span class="icon-chevron-right"></span>

								</span>
							</div>
						</div>
					</div>	

				</div>		

				<div class="destination-slider-wrap">
					<div class="destination-slider">
						<?php
						
						if(is_array($boxes)){
							foreach($boxes as $box){
								$price = isset($box['price']) ? $box['price'] : '';
								$image = isset($box['image']) ? $box['image'] : '';
								$img_url = $image['url'];
								$location = isset($box['location']) ? $box['location'] : '';
								$country = isset($box['country']) ? $box['country'] : '';
								?>
								<div class="destination">
									<div class="thumb">
										<img src="<?php echo esc_url( $img_url ); ?>" alt="Image" class="img-fluid">
										<div class="price"><?php echo esc_html( $price ); ?></div>
									</div>
									<div class="mt-4">
										<h3><a href="#"><?php echo esc_html( $location ); ?></a></h3>
										<span class="meta"><?php echo esc_html( $country ); ?></span>
									</div>
								</div>
								<?php
							}
						}
						?>
						

					</div>
				</div>

			</div>
		<?php
	}

}