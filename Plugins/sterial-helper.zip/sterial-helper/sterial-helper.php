<?php 
/**
 * Plugin Name:       Sterial Helper
 * Plugin URI:        https://wordpress.org/photoshoot-core
 * Description:       Helper plugin for our sterial theme
 * Version:           1.0.0
 * Requires at least: 4.7
 * Requires PHP:      7.2
 * Author:            Samman tasnim
 * Author URI:        https://author.example.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       sterial-helper
 * Domain Path:       /languages
 */

 // If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * The code that runs during plugin activation.
 */
function sterial_helper_activate() {
	
}
register_activation_hook( __FILE__, 'sterial_helper_activate' );

/**
 * The code that runs during plugin deactivation.
 */
function sterial_helper_deactivate() {
	
}
register_deactivation_hook( __FILE__, 'sterial_helper_deactivate' );



function sterial_helper_load_plugin_textdomain() {

    load_plugin_textdomain(
        'sterial-helper',
        false,
        __DIR__ . '/languages/'
    );

}
add_action( 'plugins_loaded', 'sterial_helper_load_plugin_textdomain' );



//Service boxes and title section
function cmb2_add_metabox_service() {

	$prefix = '_sterial_';

	$cmb = new_cmb2_box( array(
		'id'           => $prefix . 'service_section',
		'title'        => __( 'Service section', 'sterial-helper' ),
		'object_types' => array( 'page' ),
		'context'      => 'normal',
        'show_on'      => array( 'key' => 'page-template', 'value' => 'page-templates/services-template.php' ),
		'priority'     => 'default',
	) );

	$cmb->add_field( array(
		'name' => __( 'Subtitle', 'sterial-helper' ),
		'id' => $prefix . 'subtitle',
		'type' => 'text',
	) );

	$cmb->add_field( array(
		'name' => __( 'Content content', 'sterial-helper' ),
		'id' => $prefix . 'content',
		'type' => 'textarea',
	) );

    $cmb->add_field( array(
		'name' => __( 'Link', 'sterial-helper' ),
		'id' => $prefix . 'link',
		'type' => 'text',
	) );




    $boxes = $cmb->add_field( array(
		'name' => __( 'Feature boxes', 'sterial-helper' ),
		'id' => $prefix . 'service_boxes',
		'type' => 'group',
	) );

    $cmb->add_group_field($boxes, array(
		'name' => __( 'Image', 'sterial-helper' ),
		'id' => $prefix . 'box_image',
		'type' => 'file',
	) );

	$cmb->add_group_field($boxes, array(
		'name' => __( 'Box title', 'sterial-helper' ),
		'id' => $prefix . 'box_title',
		'type' => 'text',
	) );

	$cmb->add_group_field($boxes, array(
		'name' => __( 'Box content', 'sterial-helper' ),
		'id' => $prefix . 'box_content',
		'type' => 'textarea',
	) );



   

}
add_action( 'cmb2_init', 'cmb2_add_metabox_service' );


//cmb2 for about us feature section

function cmb2_add_metabox_about_feature() {

	$prefix = '_sterial_';

	$cmb = new_cmb2_box( array(
		'id'           => $prefix . 'about_feature_section',
		'title'        => __( 'Service section', 'sterial-helper' ),
		'object_types' => array( 'page' ),
		'context'      => 'normal',
        'show_on'      => array( 'key' => 'page-template', 'value' => 'page-templates/about-us-template.php' ),
		'priority'     => 'default',
	) );

	$cmb->add_field( array(
		'name' => __( 'Subtitle', 'sterial-helper' ),
		'id' => $prefix . 'subtitle',
		'type' => 'text',
	) );

	$cmb->add_field( array(
		'name' => __( 'Content', 'sterial-helper' ),
		'id' => $prefix . 'content',
		'type' => 'textarea',
	) );

    $cmb->add_field( array(
		'name' => __( 'Link', 'sterial-helper' ),
		'id' => $prefix . 'link',
		'type' => 'text',
	) );

	$cmb->add_field( array(
		'name' => __( 'Image one', 'sterial-helper' ),
		'id' => $prefix . 'box_image_one',
		'type' => 'file',
	) );

	$cmb->add_field( array(
		'name' => __( 'Image two', 'sterial-helper' ),
		'id' => $prefix . 'box_image_two',
		'type' => 'file',
	) );





   

}
add_action( 'cmb2_init', 'cmb2_add_metabox_about_feature' );

//Services post section

function cmb2_add_metabox_service_post() {

	$prefix = '_sterial_';

	$cmb = new_cmb2_box( array(
		'id'           => $prefix . 'service_post_section',
		'title'        => __( 'Post section', 'sterial-helper' ),
		'object_types' => array( 'page' ),
		'context'      => 'normal',
        'show_on'      => array( 'key' => 'page-template', 'value' => 'page-templates/services-template.php' ),
		'priority'     => 'default',
	) );

	$cmb->add_field( array(
		'name' => __( 'Subtitle', 'sterial-helper' ),
		'id' => $prefix . 'title1',
		'type' => 'text',
	) );

	$cmb->add_field( array(
		'name' => __( 'Content service content', 'sterial-helper' ),
		'id' => $prefix . 'content1',
		'type' => 'textarea',
	) );

    $cmb->add_field( array(
		'name' => __( 'Link', 'sterial-helper' ),
		'id' => $prefix . 'link1',
		'type' => 'text',
	) );

}
add_action( 'cmb2_init', 'cmb2_add_metabox_service_post' );




//Custom post type services

function sterial_services() {
    $args = array(
        'labels' => array(
            'name'           => __('Services Page', 'sterial-helper'),
            'singular_name'  => __('services', 'sterial-helper'),
            'add_new_item'   => __('Add new services Page', 'sterial-helper'),
            'edit_item'      => __('Edit Page', 'sterial-helper'),
            'item_updated'   => __('Page updated', 'sterial-helper'),
            'item_published' => __('Page published', 'sterial-helper'),
        ),
        'hierarchical' => false,
        'public'       => true,
        'has_archive'  => false,
        'supports'     => array('thumbnail', 'title', 'editor' ),
        'rewrite'      => array(
            'slug'     => 'services'
        )
    );
    register_post_type( 'services', $args );


  


}
add_action('init', 'sterial_services');




//cmb2 for team experts
function cmb2_add_metabox_abou_team_experts() {

	$prefix = '_sterial_';

	$cmb = new_cmb2_box( array(
		'id'           => $prefix . 'about_team_experts_section',
		'title'        => __( 'Team expert section', 'sterial-helper' ),
		'object_types' => array( 'page' ),
		'context'      => 'normal',
        'show_on'      => array( 'key' => 'page-template', 'value' => 'page-templates/about-us-template.php' ),
		'priority'     => 'default',
	) );

	$cmb->add_field( array(
		'name' => __( 'Subtitle', 'sterial-helper' ),
		'id' => $prefix . 'subtitle',
		'type' => 'text',
	) );

	$cmb->add_field( array(
		'name' => __( 'Content content', 'sterial-helper' ),
		'id' => $prefix . 'content',
		'type' => 'textarea',
	) );





    $boxes = $cmb->add_field( array(
		'name' => __( 'Experts boxes', 'sterial-helper' ),
		'id' => $prefix . 'experts_boxes',
		'type' => 'group',
	) );

    $cmb->add_group_field($boxes, array(
		'name' => __( 'Image', 'sterial-helper' ),
		'id' => $prefix . 'box_image',
		'type' => 'file',
	) );

	$cmb->add_group_field($boxes, array(
		'name' => __( 'Profession title', 'sterial-helper' ),
		'id' => $prefix . 'profession_title',
		'type' => 'text',
	) );

	$cmb->add_group_field($boxes, array(
		'name' => __( 'Name', 'sterial-helper' ),
		'id' => $prefix . 'name',
		'type' => 'text',
	) );

	$cmb->add_group_field($boxes, array(
		'name' => __( 'Content', 'sterial-helper' ),
		'id' => $prefix . 'content',
		'type' => 'textarea',
	) );



   

}
add_action( 'cmb2_init', 'cmb2_add_metabox_abou_team_experts' );




// register elementor widgets
function sterial_helper_elementor_widgets($widgets_manager) {
    require_once plugin_dir_path( __FILE__ ) . 'elementor-widgets/explore-widget.php';
	require_once plugin_dir_path( __FILE__ ) . 'elementor-widgets/destination-widget.php';
	require_once plugin_dir_path( __FILE__ ) . 'elementor-widgets/questions-widget.php';


    $widgets_manager->register(new Sterial_Explore_Widget());
	$widgets_manager->register(new Sterial_Destination_Widget());
	$widgets_manager->register(new Sterial_Questions_Widget());

}
add_action('elementor/widgets/register', 'sterial_helper_elementor_widgets');




   //Redux codes here
    if ( ! class_exists( 'Redux' ) ) {
        return;
    }

    $opt_name = 'sterial_options';

    $theme = wp_get_theme(); // For use with some settings. Not necessary.

    $args = array(
        'display_name'         => $theme->get( 'Name' ),
        'display_version'      => $theme->get( '1.0.0' ),
        'menu_title'           => esc_html__( 'Sterial Settings', 'sterial-helper' ),
        'customizer'           => true,
    );

    Redux::setArgs( $opt_name, $args );

    Redux::setSection( $opt_name, array(
        'title'  => esc_html__( 'Header', 'sterial-helper' ),
        'id'     => 'header',
        'desc'   => esc_html__( 'Header Settings.', 'sterial-helper' ),
        'icon'   => 'el el-home',
        'fields' => array(
            array(
                'id'       => 'header_title',
                'type'     => 'text',
                'title'    => esc_html__( 'Header title', 'sterial-helper' ),
                'desc'     => esc_html__( 'Example description.', 'sterial-helper' ),
                'subtitle' => esc_html__( 'Example subtitle.', 'sterial-helper' ),
                'hint'     => array(
                    'content' => 'This is a <b>hint</b> tool-tip for the text field.<br/><br/>Add any HTML based text you like here.',
                )
			),
			array(
                'id'       => 'header_description',
                'type'     => 'text',
                'title'    => esc_html__( 'Header Description', 'sterial-helper' ),
                'desc'     => esc_html__( 'Example description.', 'sterial-helper' ),
                'subtitle' => esc_html__( 'Example subtitle.', 'sterial-helper' ),
                'hint'     => array(
                    'content' => 'This is a <b>hint</b> tool-tip for the text field.<br/><br/>Add any HTML based text you like here.',
			    )

			),

			array(
                'id'       => 'header_link',
                'type'     => 'text',
                'title'    => esc_html__( 'Header Link', 'sterial-helper' ),
                'desc'     => esc_html__( 'Example description.', 'sterial-helper' ),
                'subtitle' => esc_html__( 'Example subtitle.', 'sterial-helper' ),
                'hint'     => array(
                    'content' => 'This is a <b>hint</b> tool-tip for the text field.<br/><br/>Add any HTML based text you like here.',
			    )

			),
        )
    ) );



	Redux::setSection( $opt_name, array(
        'title'  => esc_html__( 'Footer', 'sterial-helper' ),
        'id'     => 'footer',
        'desc'   => esc_html__( 'Footer Settings.', 'sterial-helper' ),
        'icon'   => 'el el-home',
        'fields' => array(
            array(
                'id'       => 'about_heading',
                'type'     => 'text',
                'title'    => esc_html__( 'About Footer Title', 'sterial-helper' ),
                'desc'     => esc_html__( 'Example description.', 'sterial-helper' ),
                'subtitle' => esc_html__( 'Example subtitle.', 'sterial-helper' ),
                'hint'     => array(
                    'content' => 'This is a <b>hint</b> tool-tip for the text field.<br/><br/>Add any HTML based text you like here.',
                )
			),
			array(
                'id'       => 'about_description',
                'type'     => 'text',
                'title'    => esc_html__( 'About Description', 'sterial-helper' ),
                'desc'     => esc_html__( 'Example description.', 'sterial-helper' ),
                'subtitle' => esc_html__( 'Example subtitle.', 'sterial-helper' ),
                'hint'     => array(
                    'content' => 'This is a <b>hint</b> tool-tip for the text field.<br/><br/>Add any HTML based text you like here.',
			    )

			),
			array(
                'id'       => 'social_icons',
                'type'     => 'text',
                'title'    => esc_html__( 'Social Icon', 'sterial-helper' ),
                'desc'     => esc_html__( 'Example description.', 'sterial-helper' ),
                'subtitle' => esc_html__( 'Example subtitle.', 'sterial-helper' ),
                'hint'     => array(
                    'content' => 'This is a <b>hint</b> tool-tip for the text field.<br/><br/>Add any HTML based text you like here.',
			    )

			),

			
			
			



        )
    ) );

	
