<?php
namespace FakerPress\Fields;

/**
 * Abstract for Fieldset.
 *
 * @since  0.5.2
 */
abstract class Fieldset_Abstract implements Fieldset_Interface {

}