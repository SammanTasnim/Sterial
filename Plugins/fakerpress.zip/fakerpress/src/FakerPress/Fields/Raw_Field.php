<?php
namespace FakerPress\Fields;

class Raw_Field extends Field_Abstract {
	/**
	 * {@inheritDoc}
	 */
	protected $slug = 'raw';
}