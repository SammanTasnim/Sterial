<?php
namespace FakerPress\Fields;

/**
 * Interface for Fieldset.
 *
 * @since  0.5.2
 */
interface Fieldset_Interface {

}